const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const shopBtn = document.getElementById("shopBtn");
const shopModal = document.getElementById("shopModal");
const closeShopBtn = document.getElementById("closeShopBtn");
const shopBalanceText = document.getElementById("shopBalance");

const tabBirds = document.getElementById("tabBirds");
const tabPipes = document.getElementById("tabPipes");
const tabBackgrounds = document.getElementById("tabBackgrounds");

const birdsSection = document.getElementById("birdsSection");
const pipesSection = document.getElementById("pipesSection");
const backgroundsSection = document.getElementById("backgroundsSection");

// Глобальные объекты изображений
const birdImage = new Image();
const pipeImage = new Image();
const bgImage = new Image();

// ЭКОНОМИКА: Кошелек иен и купленные скины
let yenBalance = parseInt(localStorage.getItem("flappy_yenBalance")) || 0;
let purchasedSkins = JSON.parse(localStorage.getItem("flappy_purchasedSkins")) || ["potuznolit.webp", "default"];

function saveEconomy() {
    localStorage.setItem("flappy_yenBalance", yenBalance);
    localStorage.setItem("flappy_purchasedSkins", JSON.stringify(purchasedSkins));
}

// Функции обновления путей файлов
function setBirdResource(src) { birdImage.src = src; }
function setPipeResource(src) { if (src !== "default" && src) pipeImage.src = src; }
function setBgResource(src) { if (src !== "default" && src) bgImage.src = src; }

// Первоначальное чтение памяти при загрузке страницы
let currentSkinFile = localStorage.getItem("flappy_selectedSkin") || "potuznolit.webp";
setBirdResource(currentSkinFile);

let currentPipeFile = localStorage.getItem("flappy_selectedPipe") || "default";
setPipeResource(currentPipeFile);

let currentBgFile = localStorage.getItem("flappy_selectedBg") || "default";
setBgResource(currentBgFile);

// Игровые коэффициенты физики
const GRAVITY_BASE = 0.23;
const FLAP_BASE = -6.5;
const PIPE_SPEED_BASE = 4.5;

let GRAVITY, FLAP, PIPE_SPEED, GAP, PIPE_WIDTH, BIRD_RADIUS;
let pipes = [];
let sessionYen = 0; 
let gameOver = false;
let gameStarted = false;
let isShopOpen = false;

let bird = { x: 0, y: 0, velocity: 0, rotation: 0 };

// --- МАССИВ ДЛЯ ХРАНЕНИЯ ВСПLYВАЮЩЕГО ТЕКСТА ---
let popups = []; 
// Переменная для анимации увеличения правого счётчика (размер шрифта)
let scoreFontSize = 36; 

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const scaleFactor = Math.max(canvas.height / 700, 1);

    PIPE_WIDTH = 140 * scaleFactor;
    GAP = 240 * scaleFactor;
    BIRD_RADIUS = 35 * scaleFactor;

    GRAVITY = GRAVITY_BASE * scaleFactor;
    FLAP = FLAP_BASE * scaleFactor;
    PIPE_SPEED = PIPE_SPEED_BASE * scaleFactor;

    bird.x = canvas.width * 0.15;
    if (!gameStarted && !gameOver) bird.y = canvas.height / 2;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Переключение табов магазина
function switchTab(activeTab, activeSection) {
    [tabBirds, tabPipes, tabBackgrounds].forEach(t => t.classList.remove("active"));
    [birdsSection, pipesSection, backgroundsSection].forEach(s => s.classList.add("hidden"));
    activeTab.classList.add("active");
    activeSection.classList.remove("hidden");
}

tabBirds.addEventListener("click", () => switchTab(tabBirds, birdsSection));
tabPipes.addEventListener("click", () => switchTab(tabPipes, pipesSection));
tabBackgrounds.addEventListener("click", () => switchTab(tabBackgrounds, backgroundsSection));

// Обновление состояния кнопок выбора и покупки товаров
function updateActiveCardVisuals() {
    shopBalanceText.innerText = yenBalance;

    const processCard = (card, currentFile) => {
        const id = card.getAttribute("data-skin");
        const price = parseInt(card.getAttribute("data-price"));
        const btn = card.querySelector(".select-btn");

        if (id === currentFile) {
            card.classList.add("active");
            btn.innerText = "Izvēlēts";
            btn.style.backgroundColor = "#2ecc71";
        } else {
            card.classList.remove("active");
            if (purchasedSkins.includes(id) || price === 0) {
                btn.innerText = "Izvēlēties";
                btn.style.backgroundColor = "#3498db";
            } else {
                btn.innerText = `Pirkt (${price} ¥)`;
                btn.style.backgroundColor = "#e67e22";
            }
        }
    };

    document.querySelectorAll(".bird-card").forEach(card => processCard(card, currentSkinFile));
    document.querySelectorAll(".pipe-card").forEach(card => processCard(card, currentPipeFile));
    document.querySelectorAll(".bg-card").forEach(card => processCard(card, currentBgFile));
}

shopBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    updateActiveCardVisuals();
    shopModal.classList.remove("hidden");
    isShopOpen = true;
});

closeShopBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    shopModal.classList.add("hidden");
    isShopOpen = false;
});

// Логика покупки/выбора элемента
function handleItemSelection(card, type) {
    const id = card.getAttribute("data-skin");
    const price = parseInt(card.getAttribute("data-price"));

    if (purchasedSkins.includes(id) || price === 0) {
        if (type === "bird") { currentSkinFile = id; localStorage.setItem("flappy_selectedSkin", currentSkinFile); setBirdResource(currentSkinFile); } 
        else if (type === "pipe") { currentPipeFile = id; localStorage.setItem("flappy_selectedPipe", currentPipeFile); setPipeResource(currentPipeFile); } 
        else if (type === "bg") { currentBgFile = id; localStorage.setItem("flappy_selectedBg", currentBgFile); setBgResource(currentBgFile); }
    } else {
        if (yenBalance >= price) {
            yenBalance -= price;
            purchasedSkins.push(id);
            saveEconomy();
            if (type === "bird") { currentSkinFile = id; setBirdResource(id); localStorage.setItem("flappy_selectedSkin", id); }
            if (type === "pipe") { currentPipeFile = id; setPipeResource(id); localStorage.setItem("flappy_selectedPipe", id); }
            if (type === "bg") { currentBgFile = id; setBgResource(id); localStorage.setItem("flappy_selectedBg", id); }
        } else {
            alert("Tev nepietiek jenu (¥)! / Не хватает иен!");
        }
    }
    updateActiveCardVisuals();
}

document.querySelectorAll(".bird-card").forEach(card => card.addEventListener("click", (e) => { e.stopPropagation(); handleItemSelection(card, "bird"); }));
document.querySelectorAll(".pipe-card").forEach(card => card.addEventListener("click", (e) => { e.stopPropagation(); handleItemSelection(card, "pipe"); }));
document.querySelectorAll(".bg-card").forEach(card => card.addEventListener("click", (e) => { e.stopPropagation(); handleItemSelection(card, "bg"); }));

window.addEventListener("keydown", (e) => { if (e.code === "Space" && !isShopOpen) jump(); });
window.addEventListener("touchstart", () => { if (!isShopOpen) jump(); });

function jump() {
    if (gameOver) { resetGame(); return; }
    if (!gameStarted) { gameStarted = true; shopBtn.style.display = "none"; }
    bird.velocity = FLAP;
}

function spawnPipe(isFirst = false) {
    let minHeight = 120;
    let maxHeight = canvas.height - GAP - 120;
    let topHeight = Math.floor(Math.random() * (maxHeight - minHeight + 1)) + minHeight;
    let startingX = isFirst ? canvas.width + canvas.width * 0.3 : canvas.width + 100;

    pipes.push({
        x: startingX,
        top: topHeight,
        bottom: canvas.height - topHeight - GAP,
        passed: false
    });
}

function resetGame() {
    bird.y = canvas.height / 2;
    bird.velocity = 0;
    bird.rotation = 0;
    pipes = [];
    sessionYen = 0;
    popups = [];
    scoreFontSize = 36;
    gameOver = false;
    gameStarted = false;
    shopBtn.style.display = "block";
    spawnPipe(true);
}

spawnPipe(true);

function update() {
    if (gameStarted && !gameOver) {
        bird.velocity += GRAVITY;
        bird.y += bird.velocity;

        if (bird.velocity < 0) { bird.rotation = Math.max(-0.4, bird.velocity * 0.06); } 
        else { bird.rotation = Math.min(0.45, bird.rotation + 0.015); }

        if (bird.y + BIRD_RADIUS >= canvas.height || bird.y - BIRD_RADIUS <= 0) endGame();

        for (let i = pipes.length - 1; i >= 0; i--) {
            pipes[i].x -= PIPE_SPEED;

            if (bird.x + BIRD_RADIUS > pipes[i].x && bird.x - BIRD_RADIUS < pipes[i].x + PIPE_WIDTH) {
                if (bird.y - BIRD_RADIUS < pipes[i].top || bird.y + BIRD_RADIUS > canvas.height - pipes[i].bottom) {
                    endGame();
                }
            }

            if (!pipes[i].passed && pipes[i].x + (PIPE_WIDTH / 2) < bird.x) {
                sessionYen++; 
                yenBalance++;  
                saveEconomy();
                pipes[i].passed = true;

                // 1. Создаем эффект "+1 ¥" летящий вверх над головой птицы
                popups.push({
                    x: bird.x,
                    y: bird.y - 40,
                    alpha: 1.0 // Прозрачность текста
                });

                // 2. Включаем импульс для счетчика (увеличиваем шрифт)
                scoreFontSize = 55; 
            }

            if (pipes[i].x + PIPE_WIDTH < 0) pipes.splice(i, 1);
        }

        let lastPipe = pipes[pipes.length - 1];
        if (!lastPipe || canvas.width - lastPipe.x >= (canvas.width * 0.45)) spawnPipe(false);
    } else if (!gameStarted && !gameOver) {
        bird.y = (canvas.height / 2) + Math.sin(Date.now() * 0.005) * 15;
        bird.rotation = 0;
    }

    // Возвращаем размер шрифта к исходному 36px (плавное уменьшение)
    if (scoreFontSize > 36) {
        scoreFontSize -= 1.5;
    }

    // Рассчитываем движение всплывающих текстов
    for (let i = popups.length - 1; i >= 0; i--) {
        popups[i].y -= 2;      // Движение вверх
        popups[i].alpha -= 0.02; // Растворение в воздухе
        if (popups[i].alpha <= 0) {
            popups.splice(i, 1); // Удаляем, когда стал невидимым
        }
    }

    draw();
    requestAnimationFrame(update);
}

// ОТРИСОВКА ВСЕХ СЛОЕВ ИГРЫ
function draw() {
    // 1. Отрисовка фона
    if (currentBgFile !== "default" && bgImage.complete && bgImage.naturalWidth > 0) {
        ctx.drawImage(bgImage, 0, 0, canvas.width, canvas.height);
    } else {
        ctx.fillStyle = "#70c5ce";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // 2. Отрисовка труб
    pipes.forEach(pipe => {
        if (currentPipeFile !== "default" && pipeImage.complete && pipeImage.naturalWidth > 0) {
            ctx.drawImage(pipeImage, pipe.x, 0, PIPE_WIDTH, pipe.top);
            ctx.drawImage(pipeImage, pipe.x, canvas.height - pipe.bottom, PIPE_WIDTH, pipe.bottom);
        } else {
            ctx.fillStyle = "#73bf2e";
            ctx.fillRect(pipe.x, 0, PIPE_WIDTH, pipe.top);
            ctx.fillRect(pipe.x, canvas.height - pipe.bottom, PIPE_WIDTH, pipe.bottom);
            
            ctx.fillStyle = "#538122";
            ctx.fillRect(pipe.x - 4, pipe.top - 30, PIPE_WIDTH + 8, 30);
            ctx.fillRect(pipe.x - 4, canvas.height - pipe.bottom, PIPE_WIDTH + 8, 30);
        }
    });

    // 3. Отрисовка игрока
    ctx.save();
    ctx.translate(bird.x, bird.y);
    ctx.rotate(bird.rotation);
    
    if (birdImage.complete && birdImage.naturalWidth > 0) {
        ctx.drawImage(birdImage, -BIRD_RADIUS * 1.4, -BIRD_RADIUS * 1.4, BIRD_RADIUS * 2.8, BIRD_RADIUS * 2.8);
    } else {
        ctx.fillStyle = "#f7d346";
        ctx.beginPath();
        ctx.arc(0, 0, BIRD_RADIUS, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#d1a100";
        ctx.lineWidth = 4;
        ctx.stroke();
    }
    ctx.restore();

    // --- РИСУЕМ ВСПЛЫВАЮЩИЕ АНИМАЦИИ "+1 ¥" ---
    popups.forEach(pop => {
        ctx.save();
        ctx.globalAlpha = pop.alpha; // Задаем текущую прозрачность
        ctx.fillStyle = "#f1c40f";  // Золотой цвет
        ctx.lineWidth = 5;
        ctx.strokeStyle = "black";
        ctx.font = "bold 32px Arial";
        ctx.textAlign = "center";
        ctx.strokeText("+1 ¥", pop.x, pop.y);
        ctx.fillText("+1 ¥", pop.x, pop.y);
        ctx.restore();
    });

    // 4. Текст интерфейса (Вывод иен)
    ctx.fillStyle = "white";
    ctx.lineWidth = 7;
    ctx.strokeStyle = "black";
    
    // Слева вверху - иены за этот раунд
    ctx.font = "bold 36px Arial";
    ctx.textAlign = "left";
    ctx.strokeText(`Jenas: ${sessionYen} ¥`, 40, 60);
    ctx.fillText(`Jenas: ${sessionYen} ¥`, 40, 60);

    // Справа вверху - общий баланс игрока (с динамическим размером scoreFontSize)
    ctx.textAlign = "right";
    ctx.fillStyle = "#f1c40f";
    ctx.font = `bold ${Math.floor(scoreFontSize)}px Arial`;
    ctx.strokeText(`Kopā: ${yenBalance} ¥`, canvas.width - 40, 60);
    ctx.fillText(`Kopā: ${yenBalance} ¥`, canvas.width - 40, 60);

    if (!gameStarted && !gameOver) {
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.font = "bold 42px Arial";
        ctx.strokeText("Nospied ATSTARPI, lai lidotu", canvas.width / 2, canvas.height / 2 - 80);
        ctx.fillText("Nospied ATSTARPI, lai lidotu", canvas.width / 2, canvas.height / 2 - 80);
    }

    if (gameOver) {
        ctx.textAlign = "center";
        ctx.font = "bold 56px Arial";
        ctx.fillStyle = "#e74c3c";
        ctx.strokeText("SPĒLE BEIGUSIES", canvas.width / 2, canvas.height / 2 - 30);
        ctx.fillText("SPĒLE BEIGUSIES", canvas.width / 2, canvas.height / 2 - 30);
    }
}

function endGame() {
    gameOver = true;
    shopBtn.style.display = "none";
}

update();